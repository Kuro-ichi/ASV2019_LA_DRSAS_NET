#!/usr/bin/env python
from drsas_net.engine.trainer import main
if __name__ == "__main__":
    main()
