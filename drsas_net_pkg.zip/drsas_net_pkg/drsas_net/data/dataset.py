from __future__ import annotations
from pathlib import Path
from torch.utils.data import Dataset, DataLoader
import torch

class DummyDataset(Dataset):
    def __init__(self, root: str, split: str = "train", length: int = 1000, in_channels: int = 1, num_classes: int = 10):
        self.root = Path(root)
        self.split = split
        self.length = length
        self.in_channels = in_channels
        self.num_classes = num_classes

    def __len__(self):
        return self.length

    def __getitem__(self, idx: int):
        x = torch.randn(self.in_channels, 64, 64)
        y = torch.randint(0, self.num_classes, (1,)).item()
        return x, y

def make_dataloader(root: str, split: str, batch_size: int, num_workers: int, in_channels: int, num_classes: int):
    ds = DummyDataset(root=root, split=split, in_channels=in_channels, num_classes=num_classes)
    return DataLoader(ds, batch_size=batch_size, shuffle=(split=='train'), num_workers=num_workers)
